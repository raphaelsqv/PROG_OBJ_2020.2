/*   package projeto1;

public class Snippet {
	
	public static void main(String[] args)
	
	{
		if(time1.totalPontos()>time2.totalPontos())
	}
}

*/