/*
 * Matricula: 0050010425 Raphael Vieira
 * Matricula: 0050011100 David Bastos de Souza Tinoco
 * 
 * 
 */



package projeto1;

public class TimeDeFutebol {
	private int numeroDeTorcida;

	public int getNumeroDeTorcida() {
		return numeroDeTorcida;
	}

	public void setNumeroDeTorcida(int numeroDeTorcida) {
		this.numeroDeTorcida = numeroDeTorcida;
	}
	
}
