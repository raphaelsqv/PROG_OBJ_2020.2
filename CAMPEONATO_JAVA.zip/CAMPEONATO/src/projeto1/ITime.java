/*
 * Matricula: 0050010425 Raphael Vieira
 * Matricula: 0050011100 David Bastos de Souza Tinoco
 * 
 * 
 */




package projeto1;

public interface ITime {
	
	public String printNomeTime();   
	
	public int adicionarVitoria();  
	
	public int adicionarDerrota();
	
	public int adicionarEmpate();
	
	public int totalPontos(); 
	
	public int getVitoria();   
	
	public int getDerrota();  
	
	public int getEmpate();
	
	public int totaljogos();
	
	
		
}
